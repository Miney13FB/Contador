package com.vic.contadorgta

import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime

data class Target(val label: String, val dateTime: LocalDateTime)

object CountdownLogic {

    val targets = listOf(
        Target("10 de noviembre · 00:00", LocalDateTime.of(2026, 11, 10, 0, 0)),
        Target("19 de noviembre · 00:00", LocalDateTime.of(2026, 11, 19, 0, 0))
    )

    /** Tiempo restante en la zona horaria actual del móvil. Nunca negativo. */
    fun remaining(target: Target, now: ZonedDateTime = ZonedDateTime.now()): Duration {
        val end = target.dateTime.atZone(ZoneId.systemDefault())
        val d = Duration.between(now, end)
        return if (d.isNegative) Duration.ZERO else d
    }

    fun format(d: Duration): String {
        val days = d.toDays()
        val h = d.toHours() % 24
        val m = d.toMinutes() % 60
        val s = d.seconds % 60
        return "%dd %02dh %02dm %02ds".format(days, h, m, s)
    }

    fun formatShort(d: Duration): String {
        val days = d.toDays()
        val h = d.toHours() % 24
        val m = d.toMinutes() % 60
        return "%dd %02dh %02dm".format(days, h, m)
    }
}
