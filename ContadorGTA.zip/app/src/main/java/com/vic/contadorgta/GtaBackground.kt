package com.vic.contadorgta

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

@Composable
fun GtaBackground(modifier: Modifier = Modifier.fillMaxSize()) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Cielo
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color(0xFF1A0B2E),
                0.45f to Color(0xFF7B1FA2),
                0.70f to Color(0xFFE91E63),
                1f to Color(0xFFFF8A3D)
            )
        )

        // Sol
        drawCircle(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFFE082), Color(0xFFFF6F61)),
                startY = h * 0.50f, endY = h * 0.74f
            ),
            radius = w * 0.26f,
            center = Offset(w / 2f, h * 0.62f)
        )

        // Suelo oscuro
        drawRect(
            color = Color(0xFF12061F),
            topLeft = Offset(0f, h * 0.76f),
            size = Size(w, h * 0.24f)
        )

        // Líneas de reflejo
        for (i in 0..5) {
            val y = h * (0.78f + i * 0.035f)
            drawLine(
                color = Color(0x55FF8A3D),
                start = Offset(w * (0.30f - i * 0.02f), y),
                end = Offset(w * (0.70f + i * 0.02f), y),
                strokeWidth = 3f
            )
        }

        // Palmeras
        palm(w * 0.12f, h * 0.80f, h * 0.30f)
        palm(w * 0.90f, h * 0.80f, h * 0.24f)
    }
}

private fun DrawScope.palm(baseX: Float, baseY: Float, height: Float) {
    val dark = Color(0xFF0B0314)
    val topX = baseX + height * 0.08f
    val topY = baseY - height

    drawLine(dark, Offset(baseX, baseY), Offset(topX, topY), strokeWidth = height * 0.04f)

    val leafLen = height * 0.45f
    val angles = listOf(-160f, -125f, -90f, -55f, -20f)
    angles.forEach { deg ->
        val rad = Math.toRadians(deg.toDouble())
        val endX = topX + (leafLen * Math.cos(rad)).toFloat()
        val endY = topY + (leafLen * Math.sin(rad)).toFloat() + leafLen * 0.35f
        val ctrlX = topX + (leafLen * 0.5f * Math.cos(rad)).toFloat()
        val ctrlY = topY + (leafLen * 0.5f * Math.sin(rad)).toFloat() - leafLen * 0.25f
        val p = Path().apply {
            moveTo(topX, topY)
            quadraticBezierTo(ctrlX, ctrlY, endX, endY)
        }
        drawPath(p, dark, style = Stroke(width = height * 0.035f))
    }
}
